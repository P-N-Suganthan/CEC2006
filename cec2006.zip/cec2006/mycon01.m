function [c,ceq] = mycon01(x),
%G01 (Floundas and Pardalos, 1987)
%usage: [c,ceq] = mycon01(x)

c = []; ceq = []; 